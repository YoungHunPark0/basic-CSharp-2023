﻿namespace number_5_app
{
    internal class Boiler
    {
    }
}